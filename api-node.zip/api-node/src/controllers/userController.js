const express = require('express');
const userService = require('../services/userService')

const router = express.Router();

router.get('/', async(req, res) =>{
    try{
        const users = await userService.getAll();
        console.log(users);
        res.json(users);
    }catch(err){
        console.log(err);
        res.status(400).json({error: err.message});
    }
});

router.post('/', async(req, res) => {
    console.log(req.body);
    const { username, password } = req.body;
    console.log(username, password);
    const user = await userService.register(username, password);
    res.json(user);

})

module.exports = router;